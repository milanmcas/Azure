﻿using FluentAssertions;
using ToDoApp.Server.Services;
using Xunit;

namespace ToDoApp.UnitTests
{
    public class CreateTaskShould
    {
        [Fact]
        public void ThrowErrorWhenTaskNameIsEmpty()
        {
            var service = new ToDoService();

            Action action = () => { service.CreateTodoItem(""); };

            action.Should().Throw<ArgumentException>();
        }

        [Fact]
        public void ReturnTaskWhenNameIsValid()
        {
            var service = new ToDoService();

            var todoItem = service.CreateTodoItem("abc");

            todoItem.Name.Should().Be("abc");
        }

        [Fact]
        public void SetIsCheckedToFalse()
        {
            var service = new ToDoService();

            var todoItem = service.CreateTodoItem("abc");

            todoItem.IsChecked.Should().BeFalse();
        }
    }
}
