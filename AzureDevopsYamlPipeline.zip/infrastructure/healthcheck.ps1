param (
    $stagingApiUrl
)
Start-Sleep -Seconds 5

Write-Host "Health check for $stagingApiUrl"

$response = Invoke-WebRequest -Uri $stagingApiUrl -UseBasicParsing -ErrorAction SilentlyContinue
if ($null -eq $response) {
    $statusCode = $Error[0].Exception.Response.StatusCode.Value__
    $reader = New-Object System.IO.StreamReader($Error[0].Exception.Response.GetResponseStream())
    $content = $reader.ReadToEnd() | ConvertFrom-Json
} else {
    $statusCode = $response.StatusCode
    $content = $response.Content | ConvertFrom-Json
}

if ($statusCode -eq 200 -and $content.status -eq "Healthy") {
    Write-Host $response.Content    
} else {
    Write-Host "API health check failed with status code: $statusCode and health status: $($content.status)"
    exit 1
}
