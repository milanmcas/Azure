[CmdletBinding()]
param (
    $resourceGroupName,
    $location,
    $configFileName,
    $adminUserName,
    $adminPassword
)

az group create --name $resourceGroupName --location $location
az deployment group create --resource-group $resourceGroupName `
 --template-file ./infrastructure/main.bicep `
 --parameters ./infrastructure/environments/$configFileName `
 --parameters databaseAdminUserName="$adminUserName" `
 --parameters databaseAdminPassword="$adminPassword"

