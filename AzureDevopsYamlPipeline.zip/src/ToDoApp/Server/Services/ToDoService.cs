﻿namespace ToDoApp.Server.Services
{
    public class ToDoService
    {
        public TodoItem CreateTodoItem(string name)
        {
            ArgumentException.ThrowIfNullOrEmpty(name);

            return new TodoItem(name);
        }

        public bool IsUpAndRunning()
        {
            var status = DateTime.UtcNow.Millisecond % 3;
            switch (status)
            {
                case 0:
                    return true;
                case 1:
                    return false;
                default:
                    throw new Exception("Service is down");
            }
        }
    }

    public class TodoItem
    {
        public string Name { get; }
        public bool IsChecked { get; set; }

        public TodoItem(string name)
        {
            Name = name;
        }
    }
}
