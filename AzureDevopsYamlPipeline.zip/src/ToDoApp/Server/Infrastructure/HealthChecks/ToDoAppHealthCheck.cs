using Microsoft.Extensions.Diagnostics.HealthChecks;

namespace ToDoApp.Server.Infrastructure.HealthChecks;

public class ToDoAppHealthCheck : IHealthCheck
{
    public Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = new CancellationToken())
    {
        try
        {
            return Task.FromResult(HealthCheckResult.Healthy("The ToDO service is up and running"));
           /*
            Uncomment these lines to return a random health status
            var todoService = new ToDoService();
            if (todoService.IsUpAndRunning())
            {
                return Task.FromResult(HealthCheckResult.Healthy("The ToDO service is up and running"));
            }

            return Task.FromResult(HealthCheckResult.Degraded("The ToDo service has issues"));
           */
        }
        catch (Exception e)
        {
            return Task.FromResult(HealthCheckResult.Unhealthy("The ToDo service is having issues", e));
        }
    }
}