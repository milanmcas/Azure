﻿using Microsoft.EntityFrameworkCore;

namespace ToDoApp.Storage
{
    public class ToDoDbContext: DbContext
    {
        public ToDoDbContext(DbContextOptions<ToDoDbContext> options) : base(options)
        {
        }

        public DbSet<ToDoItem> ToDoItems { get; set; } = null!;
    }

    public class ToDoItem
    {
        public Guid Id { get; set; }

        public string Name { get; set; } = null!;
        
        public string Description { get; set; } = null!;

        public DateTime? DueDate { get; set; }

        public bool IsCompleted { get; set; }

        public DateTime CreatedAt { get; set; }
    }
}
